IRON MAN MINIMAL GRUB THEME

Files:
  theme.txt      GRUB theme configuration
  background.jpg User-provided Iron Man background

Install:
  sudo mkdir -p /boot/grub/themes/ironman
  sudo cp theme.txt background.jpg /boot/grub/themes/ironman/

Then set in /etc/default/grub:
  GRUB_THEME="/boot/grub/themes/ironman/theme.txt"

Then:
  sudo update-grub

IMPORTANT:
If Kali's /etc/default/grub.d/kali-themes.cfg defines GRUB_THEME, it can override
/etc/default/grub. Remove/comment that GRUB_THEME line there, or set the same theme path.
